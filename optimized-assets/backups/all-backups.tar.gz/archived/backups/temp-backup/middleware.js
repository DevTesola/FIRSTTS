// Root middleware.js (Next.js middleware configuration)
import { NextResponse } from 'next/server';

/**
 * Middleware function for Next.js
 * Applies security headers and other middleware to all requests
 * 
 * @param {Object} request - Next.js request object
 * @returns {Object} - Next.js response object
 */
export function middleware(request) {
  // Create base response
  const response = NextResponse.next();
  
  // Apply security headers to all responses
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('X-XSS-Protection', '1; mode=block');
  response.headers.set('X-Frame-Options', 'DENY');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Add Permissions-Policy header to restrict features
  response.headers.set(
    'Permissions-Policy', 
    'accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()'
  );
  
  // Add Content-Security-Policy for API routes
  if (request.nextUrl.pathname.startsWith('/api/')) {
    response.headers.set(
      'Content-Security-Policy',
      "default-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none';"
    );
  } else {
    // Less restrictive CSP for web pages that need to load external resources
    response.headers.set(
      'Content-Security-Policy',
      "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.solana.com; connect-src 'self' https://*.solana.com wss://*.solana.com https://ipfs.io https://*.supabase.co; img-src 'self' data: https://*.pinata.cloud https://ipfs.io; style-src 'self' 'unsafe-inline'; frame-ancestors 'none';"
    );
  }
  
  // Apply HSTS header for production environment
  if (process.env.NODE_ENV === 'production') {
    response.headers.set(
      'Strict-Transport-Security',
      'max-age=63072000; includeSubDomains; preload'
    );
  }
  
  return response;
}

/**
 * Configuration for which routes this middleware applies to
 * Applied to all routes except static assets and build files
 */
export const config = {
  matcher: [
    /*
     * Match all request paths except for:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder files
     */
    '/((?!_next/static|_next/image|favicon.ico|.*\\.png$|.*\\.jpg$|.*\\.svg$).*)',
  ],
};