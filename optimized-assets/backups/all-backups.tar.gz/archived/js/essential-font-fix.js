/**
 * ESSENTIAL FONT FIX
 * 모든 폰트 관련 스크립트를 통합한 필수 파일입니다.
 */
(function() {
  console.log('Essential Font Fix: 실행됨');
  
  // 1. DM Sans 폰트를 막고 Orbitron으로 교체하는 함수
  function blockDMSansFont() {
    // FontFace API 오버라이드
    if (window.FontFace) {
      const originalFontFace = window.FontFace;
      window.FontFace = function(family, source, descriptors) {
        if (family === 'DM Sans' || (typeof family === 'string' && family.includes('DM Sans'))) {
          console.log('Essential Font Fix: DM Sans 폰트를 Orbitron으로 교체');
          family = 'Orbitron';
        }
        return new originalFontFace(family, source, descriptors);
      };
    }
    
    // Google Fonts에서 DM Sans 로딩 차단
    const originalCreateElement = document.createElement;
    document.createElement = function(tagName) {
      const element = originalCreateElement.call(document, tagName);
      
      if (tagName.toLowerCase() === 'link') {
        const originalSetAttribute = element.setAttribute;
        element.setAttribute = function(name, value) {
          if (name === 'href' && typeof value === 'string' && 
              value.includes('fonts.googleapis.com') && value.includes('DM+Sans')) {
            console.log('Essential Font Fix: Google Fonts DM Sans 로딩 차단');
            value = value.replace('DM+Sans', 'Orbitron');
          }
          return originalSetAttribute.call(this, name, value);
        };
      }
      
      return element;
    };
  }
  
  // 2. 월렛 어댑터 요소에 인라인 스타일로 폰트 적용하는 함수
  function applyOrbitronToWalletElements() {
    const walletElements = document.querySelectorAll('[class*="wallet-adapter"]');
    
    if (walletElements.length > 0) {
      console.log(`Essential Font Fix: ${walletElements.length}개의 월렛 요소에 폰트 적용`);
      
      walletElements.forEach(element => {
        element.style.setProperty('font-family', "'Orbitron', sans-serif", "important");
        
        // 모든 자식 요소에도 적용
        Array.from(element.getElementsByTagName('*')).forEach(child => {
          child.style.setProperty('font-family', "'Orbitron', sans-serif", "important");
        });
      });
    }
  }
  
  // 3. 새로운 월렛 요소가 추가될 때 감지해서 폰트를 적용하는 옵저버 설정
  function setupWalletObserver() {
    const observer = new MutationObserver(mutations => {
      let shouldApplyFont = false;
      
      mutations.forEach(mutation => {
        if (mutation.addedNodes.length > 0) {
          // 추가된 노드 중에 월렛 어댑터 요소가 있는지 확인
          mutation.addedNodes.forEach(node => {
            if (node.nodeType === 1) { // Element 노드인 경우
              if ((node.className && typeof node.className === 'string' && 
                   node.className.includes('wallet-adapter')) ||
                  (node.querySelector && node.querySelector('[class*="wallet-adapter"]'))) {
                shouldApplyFont = true;
              }
            }
          });
        }
      });
      
      if (shouldApplyFont) {
        console.log('Essential Font Fix: 새로운 월렛 요소 감지, 폰트 적용');
        applyOrbitronToWalletElements();
      }
    });
    
    // body의 모든 변경사항 감시
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });
    
    return observer;
  }
  
  // 4. 인라인 스타일 요소 추가하는 함수
  function addInlineStyleElement() {
    const style = document.createElement('style');
    style.id = 'essential-orbitron-style';
    style.innerHTML = `
      * {
        font-family: 'Orbitron', sans-serif !important;
      }
      
      .wallet-adapter-button, 
      .wallet-adapter-button *,
      .wallet-adapter-dropdown-list,
      .wallet-adapter-dropdown-list-item,
      .wallet-adapter-modal-wrapper,
      .wallet-adapter-modal-wrapper *,
      .wallet-adapter-modal-title,
      .wallet-adapter-modal-title *,
      body [class*="wallet-adapter"] {
        font-family: 'Orbitron', sans-serif !important;
      }
    `;
    
    // head의 첫 요소로 삽입해 최고 우선순위 보장
    document.head.insertBefore(style, document.head.firstChild);
  }
  
  // 모든 기능 실행
  function initEssentialFontFix() {
    blockDMSansFont();
    addInlineStyleElement();
    
    // DOM이 로드된 후 월렛 요소에 폰트 적용
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      applyOrbitronToWalletElements();
      setupWalletObserver();
    } else {
      document.addEventListener('DOMContentLoaded', function() {
        applyOrbitronToWalletElements();
        setupWalletObserver();
      });
    }
    
    // 시간차를 두고 재적용해서 비동기 로딩에도 대응
    const timeouts = [100, 500, 1000, 2000].map(delay => 
      setTimeout(applyOrbitronToWalletElements, delay)
    );
  }
  
  // 초기화 실행
  initEssentialFontFix();
})();