/**
 * Direct wallet adapter override script
 * This script directly overrides the wallet-adapter styles loaded from node_modules
 * It intercepts stylesheet loading and replaces DM Sans with Orbitron
 */
(function() {
  console.log('🔤 Direct wallet adapter override script loaded');
  
  // Find already loaded stylesheets and modify them
  function modifyExistingStylesheets() {
    // Get all stylesheet links and style elements
    const styles = [...document.getElementsByTagName('style'), ...document.getElementsByTagName('link')];
    
    styles.forEach(style => {
      // For style tags with inline CSS
      if (style.tagName === 'STYLE' && style.textContent && style.textContent.includes('DM Sans')) {
        console.log('🔤 Found style element with DM Sans, replacing with Orbitron');
        style.textContent = style.textContent.replace(/(['"])DM Sans(['"])/g, '$1Orbitron$2');
      }
      
      // For link tags loading external stylesheets
      if (style.tagName === 'LINK' && style.href && style.href.includes('wallet-adapter')) {
        console.log('🔤 Found wallet-adapter stylesheet link, will monitor and patch');
        
        // We need to fetch and replace the content
        fetch(style.href)
          .then(response => response.text())
          .then(css => {
            if (css.includes('DM Sans')) {
              console.log('🔤 Wallet adapter CSS contains DM Sans, replacing with Orbitron');
              
              // Replace DM Sans with Orbitron
              css = css.replace(/(['"])DM Sans(['"])/g, '$1Orbitron$2');
              
              // Create a new style element with our modified CSS
              const newStyle = document.createElement('style');
              newStyle.setAttribute('data-origin', style.href);
              newStyle.textContent = css;
              
              // Add it to the head
              document.head.appendChild(newStyle);
              
              // Optionally, disable the original stylesheet
              style.disabled = true;
            }
          })
          .catch(err => {
            console.error('🔤 Error fetching wallet adapter CSS:', err);
          });
      }
    });
  }
  
  // Override the fetch API to intercept wallet-adapter CSS requests
  const originalFetch = window.fetch;
  window.fetch = function(resource, options) {
    // Check if this is a request for a wallet-adapter CSS file
    if (typeof resource === 'string' && resource.includes('wallet-adapter') && resource.endsWith('.css')) {
      console.log('🔤 Intercepted fetch for wallet-adapter CSS:', resource);
      
      // Use the original fetch, but then modify the response
      return originalFetch.call(this, resource, options)
        .then(response => {
          // Clone the response so we can modify it
          const clone = response.clone();
          
          // Read the CSS
          return clone.text().then(text => {
            // Replace DM Sans with Orbitron
            const modifiedText = text.replace(/(['"])DM Sans(['"])/g, '$1Orbitron$2');
            
            // Create a new response with the modified text
            return new Response(modifiedText, {
              status: response.status,
              statusText: response.statusText,
              headers: response.headers
            });
          });
        });
    }
    
    // For all other requests, use the original fetch
    return originalFetch.call(this, resource, options);
  };
  
  // Intercept appendChild to watch for style elements
  const originalAppendChild = Node.prototype.appendChild;
  Node.prototype.appendChild = function(child) {
    // Check if this is a style or link element
    if (child && child.tagName === 'STYLE' && child.textContent && child.textContent.includes('DM Sans')) {
      console.log('🔤 Intercepted style appendChild with DM Sans, replacing with Orbitron');
      child.textContent = child.textContent.replace(/(['"])DM Sans(['"])/g, '$1Orbitron$2');
    }
    
    return originalAppendChild.call(this, child);
  };
  
  // Run the modification
  modifyExistingStylesheets();
  
  // Also run it after a delay to catch asynchronously loaded stylesheets
  setTimeout(modifyExistingStylesheets, 500);
  setTimeout(modifyExistingStylesheets, 1000);
  setTimeout(modifyExistingStylesheets, 2000);
  
  // Set up a MutationObserver to watch for new stylesheets
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.addedNodes.length > 0) {
        mutation.addedNodes.forEach(node => {
          if (
            (node.tagName === 'STYLE' && node.textContent && node.textContent.includes('DM Sans')) ||
            (node.tagName === 'LINK' && node.href && node.href.includes('wallet-adapter'))
          ) {
            console.log('🔤 Detected new style/link element, running modification');
            modifyExistingStylesheets();
          }
        });
      }
    });
  });
  
  // Start observing the head for changes
  observer.observe(document.head, {
    childList: true,
    subtree: true
  });
  
})();