// Radical approach to force Orbitron font everywhere
(function() {
  console.log('Force Orbitron script executed');

  // Create a style element to inject global CSS with highest priority
  function injectGlobalStyle() {
    const style = document.createElement('style');
    style.id = 'force-orbitron-style';
    style.innerHTML = `
      /* Override all fonts with !important and high specificity */
      html body * {
        font-family: 'Orbitron', sans-serif !important;
      }
      
      /* Additional selectors for special cases */
      html body [class], 
      html body div, 
      html body span,
      html body button,
      html body a,
      html body p,
      html body h1,
      html body h2,
      html body h3,
      html body h4,
      html body h5,
      html body h6,
      html body input,
      html body textarea,
      html body select,
      html body label {
        font-family: 'Orbitron', sans-serif !important;
      }
      
      /* Target elements with inline styles */
      [style*="font-family"] {
        font-family: 'Orbitron', sans-serif !important;
      }
    `;
    
    // Insert at the beginning of head for highest priority
    document.head.insertBefore(style, document.head.firstChild);
    console.log('Global Orbitron style injected');
  }
  
  // Run immediately if document is already loaded
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    injectGlobalStyle();
  } else {
    // Otherwise wait for DOMContentLoaded
    document.addEventListener('DOMContentLoaded', injectGlobalStyle);
  }
  
  // Also apply to all elements on the page
  function applyOrbitronToAllElements() {
    const allElements = document.querySelectorAll('*');
    console.log(`Applying Orbitron to ${allElements.length} elements`);
    
    allElements.forEach(el => {
      if (el.style) {
        el.style.setProperty('font-family', "'Orbitron', sans-serif", "important");
      }
    });
  }
  
  // Apply after a delay and periodically
  setTimeout(applyOrbitronToAllElements, 500);
  setTimeout(applyOrbitronToAllElements, 1000);
  setTimeout(applyOrbitronToAllElements, 2000);
  
  // Override CSS API
  const originalCreateElement = document.createElement;
  document.createElement = function(tagName) {
    const element = originalCreateElement.call(document, tagName);
    
    if (tagName.toLowerCase() === 'style' || tagName.toLowerCase() === 'link') {
      const originalSetAttribute = element.setAttribute;
      element.setAttribute = function(name, value) {
        if (name === 'href' && value.includes('fonts.googleapis.com') && !value.includes('Orbitron')) {
          console.log('Blocking non-Orbitron font:', value);
          // Block loading of non-Orbitron fonts
          return;
        }
        return originalSetAttribute.call(this, name, value);
      };
    }
    
    return element;
  };
  
  // Override FontFace API
  if (window.FontFace) {
    const originalFontFace = window.FontFace;
    window.FontFace = function(family, source, descriptors) {
      // Only allow Orbitron font
      if (!family.includes('Orbitron')) {
        console.log('Redirecting font family to Orbitron:', family);
        family = 'Orbitron';
      }
      return new originalFontFace(family, source, descriptors);
    };
  }
})();